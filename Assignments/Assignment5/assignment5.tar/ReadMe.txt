Program    :    Comp 2404 Assignment 5
Author     :    Nikhil Sharma 101284046
Date       :    9 April 2023

Program    :    The program will to manage the animal and customer data for a veterinary clinic. The
                end user will be able to print all the clinic data (both animals, customers and appointment), or 
                print the animal or customer information only


Source files:   Appt.cc Control.cc Date.cc Main.cc Schedule.cc Time.cc View.cc Identifiable.cc Customer.cc Clinic.cc Animal.cc
                Collection.cc IdArray.cc IdList.cc

Header files:   Appt.h Control.h Date.h Schedule.h Time.h View.h Identifiable.h Customer.h Clinic.h Animal.h Collection.h 
                IdArray.h IdList.h CompareAge.h CompareBehaviour.h CompareDate.h List.h

Data Files  : n/a

Compilation : make

launching   : ./result
