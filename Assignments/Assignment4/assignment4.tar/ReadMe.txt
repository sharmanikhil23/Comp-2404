Program    :    Comp 2404 Assignment 4
Author     :    Nikhil Sharma 101284046
Date       :    28 February 2023

Program    :    The program will to manage the animal and customer data for a veterinary clinic. The
                end user will be able to print all the clinic data (both animals and customers), or 
                print the animal or customer information only


Source files:   Animal.cc, Clinic.cc, Collection.cc, Control.cc, Customer.cc, IdArray.cc, 
                Identifiable.cc, IdList.cc, Main.cc, View.cc

Header files:   Animal.h, Clinic.h, Collection.h, Control.h, Customer.h, IdArray.h, 
                Identifiable.h, IdList.h, defs.h, View.h

Data Files  : n/a

Compilation : make

launching   : ./assignment4
