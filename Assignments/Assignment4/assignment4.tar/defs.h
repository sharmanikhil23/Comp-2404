#ifndef DEFS_H
#define DEFS_H

#define MAX_ARR        128

#define ANIMAL_IDS    1001
#define CUSTOMER_IDS  4001

typedef enum {C_DOG, C_CAT, C_SPEC_OTHER} SpeciesType;  

#endif

