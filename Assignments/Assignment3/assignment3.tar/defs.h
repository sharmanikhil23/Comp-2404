#ifndef DEFS_H
#define DEFS_H

#define MAX_ARR  256

#define OPEN_HR   17
#define CLOSE_HR  23
#define RSV_HR     2
#define MAX_TABLE_CAP 6

#endif

