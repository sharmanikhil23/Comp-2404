Program    : Comp 2404 Assignment 2
Author     : Nikhil Sharma 101284046
Date       : 15 February 2023

Program    : The restaurant data will include a reservation schedule, as well as a collection of registere
             patrons (i.e. the guests of the restaurant). The program will allow the end user create a new
             reservation. They will also be able to print out the restaurant data, including the master
             schedule of all reservations, the reservations for a single day, and the list of registered
             patrons.

Source files: Control.cc, Date.cc, main.cc, Patron.cc, PatronArray.cc, Reservation.cc, Restaurant.cc,
              RsvArray.cc
Header files: Control.h, Date.h, defs.h, Patron.h, PatronArray.h, Reservation.h, Restaurant.h, RsvArray.h

Data Files  : n/a

Compilation : make

launching   : ./result
